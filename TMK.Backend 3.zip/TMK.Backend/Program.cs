using System.Text.Json;
using System.Text.Json.Serialization;
using System.Collections.Concurrent;
using System.Text.RegularExpressions;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);

// по умолчанию слушаем 5055, чтобы не было конфликта с занятым 5000
builder.WebHost.UseUrls("http://localhost:5055");

builder.Services.AddCors(opt => opt.AddPolicy("any", p => p
    .AllowAnyOrigin()
    .AllowAnyHeader()
    .AllowAnyMethod()));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<DataStore>();

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors("any");

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapGet("/api/health", () => new { ok = true, ts = DateTimeOffset.UtcNow });
app.MapGet("/api/meta/types", (DataStore data) => data.Types.Values);
app.MapGet("/api/meta/stocks", (DataStore data) => data.Stocks.Values);

// основной эндпоинт
app.MapGet("/api/products", (DataStore data, string? q, string? typeId, string? stockId,
                             double? dMin, double? dMax, double? sMin, double? sMax,
                             int page = 1, int pageSize = 24) =>
{
    var all = data.GetMerged();

    if (!string.IsNullOrWhiteSpace(q))
    {
        var rx = new Regex(Regex.Escape(q.Trim()), RegexOptions.IgnoreCase);
        all = all.Where(p =>
            rx.IsMatch(p.Name ?? "") ||
            rx.IsMatch(p.Manufacturer ?? "") ||
            rx.IsMatch(p.TypeName ?? "")
        ).ToList();
    }

    if (!string.IsNullOrWhiteSpace(typeId))
        all = all.Where(p => p.IDType == typeId).ToList();

    if (!string.IsNullOrWhiteSpace(stockId))
        all = all.Where(p => p.IDStock == stockId).ToList();

    if (dMin is not null) all = all.Where(p => (p.Diameter ?? 0) >= dMin).ToList();
    if (dMax is not null) all = all.Where(p => (p.Diameter ?? 0) <= dMax).ToList();
    if (sMin is not null) all = all.Where(p => (p.PipeWallThickness ?? 0) >= sMin).ToList();
    if (sMax is not null) all = all.Where(p => (p.PipeWallThickness ?? 0) <= sMax).ToList();

    var total = all.Count;
    var items = all.Skip((page - 1) * pageSize).Take(pageSize).ToList();

    return Results.Ok(new { total, page, pageSize, items });
});

app.MapGet("/api/products/{id}", (DataStore data, string id) =>
{
    var item = data.GetMerged().FirstOrDefault(p => p.ID == id);
    return item is null ? Results.NotFound() : Results.Ok(item);
});

// новый эндпоинт для проверки загрузки
app.MapGet("/api/debug", (DataStore data) => new {
    types = data.Types.Count,
    stocks = data.Stocks.Count,
    noms = data.Noms.Count,
    remnants = data.Remnants.Count,
    prices = data.Prices.Count,
    merged = data.GetMerged().Count
});

app.MapFallbackToFile("index.html");

app.Run();


// ====== MODELS ======

record TypeEl { public string? IDType { get; init; } public string? Type { get; init; } public string? IDParentType { get; init; } }
record StockEl { public string? IDStock { get; init; } public string? Name { get; init; } public string? City { get; init; } public string? Address { get; init; } }
record NomenclatureEl
{
    public string? ID { get; init; }
    public string? IDCat { get; init; }
    public string? IDType { get; init; }
    public string? IDTypeNew { get; init; }
    public string? ProductionType { get; init; }
    public string? IDFunctionType { get; init; }
    public string? Name { get; init; }
    public string? Gost { get; init; }
    public string? FormOfLength { get; init; }
    public string? Manufacturer { get; init; }
    public string? SteelGrade { get; init; }
    public double? Diameter { get; init; }
    public double? PipeWallThickness { get; init; }
}
record RemnantEl
{
    public string? ID { get; init; }
    public string? IDStock { get; init; }
    public double? InStockT { get; init; }
    public double? InStockM { get; init; }
    public double? AvgTubeWeight { get; init; }
}
record PriceEl
{
    public string? ID { get; init; }
    public string? IDStock { get; init; }
    public double? PriceT { get; init; }
    public double? PriceM { get; init; }
    public int? NDS { get; init; }
}
record ProductDto
{
    public string? ID { get; init; }
    public string? Name { get; init; }
    public string? IDType { get; init; }
    public string? TypeName { get; init; }
    public string? Manufacturer { get; init; }
    public string? Gost { get; init; }
    public double? Diameter { get; init; }
    public double? PipeWallThickness { get; init; }
    public string? IDStock { get; init; }
    public string? StockName { get; init; }
    public double? InStockM { get; init; }
    public double? InStockT { get; init; }
    public double? PriceT { get; init; }
    public double? PriceM { get; init; }
    public int? NDS { get; init; }
    public string? SteelGrade { get; init; }
    public double? AvgTubeWeight { get; init; }
}


// ====== DATASTORE ======

class DataStore
{
    readonly ILogger<DataStore> _logger;
    readonly string _dataPath;
    readonly object _lock = new();

    public ConcurrentDictionary<string, TypeEl> Types { get; private set; } = new();
    public ConcurrentDictionary<string, StockEl> Stocks { get; private set; } = new();
    public ConcurrentDictionary<string, NomenclatureEl> Noms { get; private set; } = new();
    public ConcurrentDictionary<string, RemnantEl> Remnants { get; private set; } = new();
    public ConcurrentDictionary<string, PriceEl> Prices { get; private set; } = new();

    FileSystemWatcher? _watcher;
    static readonly JsonSerializerOptions JsonOpts = new() { PropertyNameCaseInsensitive = true, NumberHandling = JsonNumberHandling.AllowReadingFromString };

    public DataStore(ILogger<DataStore> logger, IWebHostEnvironment env)
    {
        _logger = logger;
        _dataPath = Path.Combine(env.ContentRootPath, "Data");
        LoadAll();
        _watcher = new FileSystemWatcher(_dataPath, "*.json")
        {
            EnableRaisingEvents = true,
            NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size | NotifyFilters.FileName
        };
        _watcher.Changed += (_, __) => DebouncedReload();
        _watcher.Created += (_, __) => DebouncedReload();
        _watcher.Renamed += (_, __) => DebouncedReload();
    }

    System.Threading.Timer? _debounce;
    void DebouncedReload()
    {
        _debounce?.Dispose();
        _debounce = new System.Threading.Timer(_ => { try { LoadAll(); } catch (Exception ex) { _logger.LogError(ex, "Reload failed"); } }, null, 400, System.Threading.Timeout.Infinite);
    }

    void LoadAll()
    {
        lock (_lock)
        {
            Types = new(ReadTypes());
            Stocks = new(ReadStocks());
            Noms = new(ReadNoms());
            Remnants = new(ReadRemnants());
            Prices = new(ReadPrices());
        }
    }

    static JsonElement GetArrayFlexible(JsonElement root, params string[] preferredKeys)
    {
        if (root.ValueKind == JsonValueKind.Array) return root;

        if (root.ValueKind == JsonValueKind.Object)
        {
            foreach (var k in preferredKeys)
                if (root.TryGetProperty(k, out var arr) && arr.ValueKind == JsonValueKind.Array)
                    return arr;

            foreach (var prop in root.EnumerateObject())
                if (prop.Value.ValueKind == JsonValueKind.Array)
                    return prop.Value;
        }
        return default;
    }

    Dictionary<string, TypeEl> ReadTypes() => ReadJson<TypeEl>("types.json", "ArrayOfTypeEl", x => x.IDType);
    Dictionary<string, StockEl> ReadStocks() => ReadJson<StockEl>("stocks.json", "ArrayOfStockEl", x => x.IDStock);
    Dictionary<string, NomenclatureEl> ReadNoms() => ReadJson<NomenclatureEl>("nomenclature.json", "ArrayOfNomenclatureEl", x => x.ID);
    Dictionary<string, RemnantEl> ReadRemnants() => ReadJson<RemnantEl>("remnants.json", "ArrayOfRemnantEl", x => x.ID);
    Dictionary<string, PriceEl> ReadPrices() => ReadJson<PriceEl>("prices.json", "ArrayOfPricesEl", x => x.ID);

    Dictionary<string, T> ReadJson<T>(string filename, string wrapper, Func<T, string?> getKey)
    {
        var path = Path.Combine(_dataPath, filename);
        var dict = new Dictionary<string, T>();
        if (!File.Exists(path)) return dict;

        using var doc = JsonDocument.Parse(File.ReadAllText(path));
        var arr = GetArrayFlexible(doc.RootElement, wrapper);
        if (arr.ValueKind != JsonValueKind.Array) return dict;

        foreach (var el in arr.EnumerateArray())
        {
            var obj = el.Deserialize<T>(JsonOpts)!;
            var key = getKey(obj);
            if (!string.IsNullOrWhiteSpace(key))
                dict[key!] = obj;
        }
        _logger.LogInformation($"{filename} loaded: {dict.Count}");
        return dict;
    }

    public List<ProductDto> GetMerged()
    {
        var result = new List<ProductDto>(Noms.Count);
        foreach (var (id, nom) in Noms)
        {
            Remnants.TryGetValue(id, out var rem);
            Prices.TryGetValue(id, out var price);
            string? stockId = rem?.IDStock ?? price?.IDStock;
            Stocks.TryGetValue(stockId ?? "", out var stock);
            Types.TryGetValue(nom.IDType ?? "", out var type);

            result.Add(new ProductDto
            {
                ID = id,
                Name = nom.Name,
                IDType = nom.IDType,
                TypeName = type?.Type,
                Manufacturer = nom.Manufacturer,
                Gost = nom.Gost,
                Diameter = nom.Diameter,
                PipeWallThickness = nom.PipeWallThickness,
                IDStock = stockId,
                StockName = stock?.Name,
                InStockM = rem?.InStockM,
                InStockT = rem?.InStockT,
                SteelGrade = nom.SteelGrade,
                AvgTubeWeight = rem?.AvgTubeWeight,
                PriceT = price?.PriceT,
                PriceM = price?.PriceM,
                NDS = price?.NDS
            });
        }
        return result;
    }
}
